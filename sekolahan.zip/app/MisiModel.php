<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MisiModel extends Model
{
    //
    protected $table = 'misi';
    public $timestamps = false;
    public $incrementing = false;
}
