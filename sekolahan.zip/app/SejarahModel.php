<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SejarahModel extends Model
{
    //
    protected $table = 'sejarah';
    public $timestamps = false;
    public $incrementing = false;
}
