<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VisiModel extends Model
{
    //
    protected $table = 'visi';
    public $timestamps = false;
    public $incrementing = false;
}
