<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TentangModel extends Model
{
    //
    protected $table = 'tentang'; 
    public $timestamps = false;
    public $incrementing = false;
}
