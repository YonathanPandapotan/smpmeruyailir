<?php $__env->startSection('kontent'); ?>
<section class="detail-siswa">
    <div class="detail-siswa-content">
        <?php if(!isset($data['siswa'])){?>
            <div class="card-detail-siswa">
                <div class="card-detail-siswa-desc">
                <h2>Siswa tidak ditemukan</h2>
                <p>Maaf kami tidak dapat menemukan siswa yang anda cari</p>
                </div>
            </div>
        <?php } else { ?>
            <div class="card-detail-siswa">
                <?php if($data['siswa']->gambarPeserta) { ?> 
                    <img class="card-detail-siswa-img" src="/images/siswa/<?php echo e($data['siswa']->gambarPeserta); ?>" alt="<?php echo e($data['siswa']->namaPeserta); ?>">
                <?php } else { ?>
                    <img src="/images/no_user.jpg" class="card-detail-siswa-img">
                <?php } ?>
                <div class="card-detail-siswa-desc">
                    <h3><?php echo e($data['siswa']->namaPeserta); ?></h3>
                    <table class="card-detail-siswa-table">
                        <tr>
                            <td>NISN</td>
                            <td>:</td>
                            <td><?php echo e($data['siswa']->nisn); ?></td>
                        </tr>
                        <tr>
                            <td>Tempat, Tanggal lahir</td>
                            <td>:</td>
                            <td><?php echo e($data['siswa']->tempatLahir.', '.$data['siswa']->tanggalLahir); ?></td>
                        </tr>
                        <tr>
                            <td>Kelas</td>
                            <td>:</td>
                            <td>IX 8</td>
                        </tr>
                        <tr>
                            <td>Walikelas</td>
                            <td>:</td>
                            <td>Rhina .N</td>
                        </tr>
                    </table>
                    <h3>Hasil Nilai</h3>
                    <table class="card-detail-siswa-table">
                        <tr>
                            <td>Bahasa Indonesia</td>
                            <td>:</td>
                            <td><?php echo e($data['siswa']->bin); ?></td>
                        </tr>
                        <tr>
                            <td>Bahasa Inggris</td>
                            <td>:</td>
                            <td><?php echo e($data['siswa']->ing); ?></td>
                        </tr>
                        <tr>
                            <td>Matematika</td>
                            <td>:</td>
                            <td><?php echo e($data['siswa']->mat); ?></td>
                        </tr>
                        <tr>
                            <td>Ilmu Pengetahuan Alam</td>
                            <td>:</td>
                            <td><?php echo e($data['siswa']->ipa); ?></td>
                        </tr>
                        <tr>
                            <td>Nilai Akhir</td>
                            <td>:</td>
                            <td><?php echo e($data['siswa']->jumlahNilai); ?></td>
                        </tr>
                    </table>
                </div>
            </div>
        <?php }?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usery/SchoolProject/REWORKED/webSekolah/resources/views/siswa-detail.blade.php ENDPATH**/ ?>