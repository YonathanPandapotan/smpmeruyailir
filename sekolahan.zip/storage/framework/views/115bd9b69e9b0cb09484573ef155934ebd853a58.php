<?php $__env->startSection('kontent'); ?>
<section class="student">
    <div class="student-content">
        <?php foreach ($data['alumni'] as $alumni) { ?>
            <div class="card-student">
                <?php if($alumni->gambarPeserta) { ?> 
                    <img class="card-student-img" src="/images/siswa/<?php echo e($alumni->gambarPeserta); ?>" alt="<?php echo e($alumni->namaPeserta); ?>">
                <?php } else { ?>
                    <img class="card-student-img" src="/images/no_user.jpg" alt="<?php echo $alumni->alumni?>">
                <?php } ?>
                <div class="card-student-desc">
                        <h3><?php echo $alumni->namaPeserta ?></h3>
                        <p><?php echo $alumni->pesanAlumni ?></p>
                </div>
            </div>
        <?php } ?>  
        </div>
        <?php echo e($data['alumni']->links('pagination')); ?>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usery/SchoolProject/REWORKED/webSekolah/resources/views/alumni.blade.php ENDPATH**/ ?>