<div class="pagination">
    <!-- Previous Page Link -->
    <?php if($paginator->onFirstPage()): ?>
        <a class="disabled page gradient" ><span>&laquo;</span></a>
    <?php else: ?>
        <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" class="page gradient">&laquo;</a>
    <?php endif; ?>

    <!-- Pagination Elements -->
    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- "Three Dots" Separator -->
        <?php if(is_string($element)): ?>
            <a class="disabled page gradient"><span><?php echo e($element); ?></span></a>
        <?php endif; ?>

        <!-- Array Of Links -->
        <?php if(is_array($element)): ?>
            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                    <a class="page gradient active"><span><?php echo e($page); ?></span></a>
                <?php else: ?>
                    <a class="page gradient" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Next Page Link -->
    <?php if($paginator->hasMorePages()): ?>
        <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" class="page gradient">&raquo;</a>
    <?php else: ?>
        <a class="page gradient disabled"><span>&raquo;</span></a>
    <?php endif; ?>
</div><?php /**PATH /home/usery/SchoolProject/REWORKED/webSekolah/resources/views/pagination.blade.php ENDPATH**/ ?>