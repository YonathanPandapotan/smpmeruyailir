<?php $__env->startSection('kontent'); ?>
<section class="detail-siswa">
    <div class="detail-siswa-content">
        <div class="card-detail-siswa">
            <h3>Maaf siswa tidak dapat ditemukan</h3>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usery/SchoolProject/REWORKED/webSekolah/resources/views/siswa-notfound.blade.php ENDPATH**/ ?>