<?php $__env->startSection('kontent'); ?>
<div style="margin-top: 100px;">
    <h2>Maaf halaman yang ada cari tidak dapat ditemukan</h2>
    <h6>Tolong periksa alamat URL anda</h6>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usery/SchoolProject/REWORKED/webSekolah/resources/views/errors/404notfound.blade.php ENDPATH**/ ?>