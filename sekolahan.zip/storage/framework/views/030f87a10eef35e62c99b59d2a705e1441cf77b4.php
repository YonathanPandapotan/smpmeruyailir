<?php $__env->startSection('kontent'); ?>
<section id="galleri">
    <h1 class="title">Galeri</h1>

    <div class="gallery-container" id="images">
        <?php
            foreach ($data['gallery'] as $gallery) {?>
            <div class="card-galleri"><div class="img"><img src="/images/gallery/<?php echo e($gallery->idGambar); ?>" alt="<?php echo e($gallery->deskripsi); ?>"></div></div>
            <?php } ?>
    </div>
    <?php echo e($data['gallery']->links('pagination')); ?>

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('upper-script'); ?>
    <link rel="stylesheet" href="https://unpkg.com/viewerjs/dist/viewer.css" />
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://unpkg.com/viewerjs/dist/viewer.js"></script>
    <script src="https://fengyuanchen.github.io/jquery-viewer/js/jquery-viewer.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $('#images').viewer();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/usery/SchoolProject/REWORKED/webSekolah/resources/views/galeri.blade.php ENDPATH**/ ?>