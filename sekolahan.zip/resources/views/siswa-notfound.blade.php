@extends('template')

@section('kontent')
<section class="detail-siswa">
    <div class="detail-siswa-content">
        <div class="card-detail-siswa">
            <h3>Maaf siswa tidak dapat ditemukan</h3>
        </div>
    </div>
</section>
@endsection