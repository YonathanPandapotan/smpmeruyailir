@extends('template')

@section('kontent')
<div style="margin-top: 100px;">
    <h2>Maaf halaman yang ada cari tidak dapat ditemukan</h2>
    <h6>Tolong periksa alamat URL anda</h6>
</div>
@endsection